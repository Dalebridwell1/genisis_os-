# Designed by Fulton Bridwell
# install_and_build.py
# Automatically sets up Genesis project locally

import os
from pathlib import Path

folders = ["src", "data", "training", "logs"]
base = Path.cwd()

def build_structure():
    for folder in folders:
        target = base / folder
        target.mkdir(exist_ok=True)
        print(f"Created: {target}")

    # Write default main script
    main_script = """# Designed by Fulton Bridwell
# genesis_main.py
# Auto-generated Genesis root handler

def main():
    print("Genesis system booting...")
    print("Verifying covenant...")
    print("Root initialized. Ready for task parsing and soulprint reflection.")

if __name__ == "__main__":
    main()
"""
    with open(base / "src/genesis_main.py", "w") as f:
        f.write(main_script)

    print("\nGenesis auto-repository is ready.")

if __name__ == "__main__":
    build_structure()
